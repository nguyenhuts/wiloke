<?php 
$atunnaDefault = wp_parse_args($this->aOptions, array("settings"=>array("title"=> array(""), "sub_title"=>array(""), "img_url"=>array(" "), "description"=>array(""), "span"=>array(""), "link_title"=>array(""), "link_url"=>array("") )) );
?>

<div class="panel-body">
	<div class="container-12-fluid sl-hn">
		<div class="container-12-row">
			<div class="large-12">

			</div>
			<div class="large-12">

				<?php 
				foreach ($atunnaDefault['settings']['img_url'] as $k => $v) :
					$v = ltrim($v);
					$title = isset($atunnaDefault['settings']['title'][$k]) ?  esc_attr($atunnaDefault['settings']['title'][$k]) : '';
					$createTitle = !empty($title) ? $title : 'Slide';
					$checkEmptyTitle = ltrim($createTitle);
					$createTitle = empty($checkEmptyTitle)  ? 'Slide' : $createTitle;
				?>

				<div class="accordion">

					<!-- ccordion-wrap -->
					<div class="accordion-wrap wrap-slide">
						<h3 class="accordion-toggle">
							
							<span><?php echo $createTitle ?></span>
							<a href="#" class="right wo-delete-image" title="Delete layer"><i class="fa fa-times"></i></a>
						</h3>
						<div class="accordion-content">
							<div class="container-12-fluid">
								<div class="large-6">
									<div class="image-wrap">
									<?php if ( !empty($v) ) : ?>
									<img src="<?php echo esc_url($v); ?>">

									<?php else : ?>
									<img src="<?php echo plugin_dir_url(__FILE__) .'assets/images/no-img.jpg'; ?>">
									<?php endif; ?>
									</div>
									<br>
									<a class="btn btn-white upload-img" data-append=".image-wrap" data-insertlink=".wo-insert-link">Get image</a>
								
									<input type="hidden" name="tunna_slider[settings][img_url][]" class="insertlink" value="<?php echo esc_url($v) ;?>">
									
								</div>
								<div class="large-6">
									<!-- Editer -->
									<div class="editer">
										<div class="editor-wrap">
											<div class="edit-wrap">
												<h4 class="editer-title box-last"><?php _e('Title', 'wiloke'); ?></h4>
												<div class="editer-content">
													<div class="form-group">			                    
								                        <div class="controls">
								                           <input type="text" name="tunna_slider[settings][title][]" value="<?php echo !empty($title) ? esc_attr($title) : ''; ?>" class="form-control">
								                        </div>
								                    </div>
												</div>
											</div> 
											<div class="edit-wrap">
												<h4 class="editer-title box-last"><?php _e('Sub title', 'wiloke'); ?></h4>
												<div class="editer-content">
													<div class="form-group">			                    
								                        <div class="controls">
								                           <input type="text" name="tunna_slider[settings][sub_title][]" value="<?php echo !empty($atunnaDefault['settings']['sub_title'][$k]) ? esc_attr($atunnaDefault['settings']['sub_title'][$k]) : ''; ?>" class="form-control">
								                        </div>
								                    </div>
												</div>
											</div> 
											<div class="edit-wrap">
												<h4 class="editer-title box-first"><?php _e('Description', 'wiloke'); ?></h4>
												<div class="editer-content">
								                    <div class="form-group">
								                        <div class="controls">
								                          <textarea name="tunna_slider[settings][description][]"><?php echo isset($atunnaDefault['settings']['description'][$k])  ? wp_unslash($atunnaDefault['settings']['description'][$k]) : ''; ?></textarea>
								                          <p class="help"><?php _e('Allow use tags: &lt;br>, &lt;i>, &lt;span>, &lt;strong>', 'wiloke'); ?></p>
								                        </div>
								                    </div>
												</div>
											</div> <!-- /edit-wrap -->
											<div class="edit-wrap">
												<h4 class="editer-title box-first"><?php _e('Button', 'wiloke'); ?></h4>
												<div class="editer-content">
								                    <div class="form-group">
								                        <div class="controls">
								                          <input type="text" name="tunna_slider[settings][button_name][]" value="<?php echo !empty($atunnaDefault['settings']['button_name'][$k]) ? esc_attr($atunnaDefault['settings']['button_name'][$k]) : ''; ?>" class="form-control" placeholder="Button Name"> <br>
								                          <input type="text" name="tunna_slider[settings][button_link][]" value="<?php echo !empty($atunnaDefault['settings']['button_link'][$k]) ? esc_attr($atunnaDefault['settings']['button_link'][$k]) : ''; ?>" class="form-control" placeholder="Button Link">
								                        </div>
								                    </div>
												</div>
											</div> <!-- /edit-wrap -->
										</div>
									</div>
									
								</div>
							</div>
						</div>
						<!-- END -->
					</div> <!-- /ccordion-wrap -->
					
					<!-- ccordion-wrap -->
				</div>

				<?php 
				endforeach;
				?>

				<div class="wo-wrap-add-slider">
					<button class="button wo-add-new"><?php _e('Add new layer', 'wiloke'); ?></button>
					<span class="spinner" style="display: none;"></span>
				</div>

			</div>

		</div>
	</div>
</div>


