(function($) {

	"use strict";
	
	jQuery(document).ready(function($) {

		// $(function() {
		// 	if($("#main-tab").length > 0) {
		// 		$( "#main-tab" ).tabs();
		// 	}
		
		// });

	   	$(document).on("click", ".wo-delete-image", function(event)
        {
        	// $(this).parents(".accordion-toggle").unbind("click");
        	event.preventDefault();
        	$(this).parents(".wrap-slide").fadeOut('slow', function()
        	{
        		$(this).remove();
        	})
        })

		//==================================
		$(document).on( 'click', '.accordion-toggle', function(event) {
			event.preventDefault();
			// if ( !$(this).hasClass("wo-delete-image") )
			// {
				$(this).toggleClass("toggle-class");
				$(this).next().slideToggle(500);
			// }
		});

		function toggleAwesome(xthis)
		{
			xthis.find("h3.accordion-toggle").trigger('click');
			xthis.next().find("h3.accordion-toggle").trigger("click");
		}

		$('.accordion-wrap').find('.accordion-content').first().css( "display", "block" );
		//==================================
		
		//==================================
		$(document).on('click', '.editer-title', function(event) {

			$(this).toggleClass("editer-title-class");
			$(this).next().slideToggle(500);

		});
		$('.edit-wrap').first().find('.editer-content').css( "display", "block" );
		//==================================

		$(document).on("click", ".wo-add-new", function(event)
		{
			event.preventDefault();
			var _self = $(this);

			$.ajax(
			{
				type: 'POST',
				url: WO_AJAX.ajax_url,
				data: {action: 'add-slider'},
				cache: true,
				beforeSend: function(xhr)
				{
					_self.next().fadeIn();
				},
				success: function(res)
				{
					_self.parent().before(res);
					var getThis = _self.parent().prev().prev();
					toggleAwesome(getThis);
				},
				complete: function(res)
				{
					_self.next().fadeOut();
				},
				error: function(res)
				{
					alert("Something go error!");
				}
			})
		})

		$(document).on("click", ".upload-img",function(){

			// var options = {
			// 		frame:    'post',
			// 		state:    'insert',
			// 		title:    wp.media.view.l10n.addMedia,
			// 		multiple: true
			// 	};		
			
			// wp.media.editor.open( "content", options );

            var current = $(this), insertTo = current.data("append"), insertLink=current.data("insertLink");
            console.log(insertTo);
            var send_attachment_bkp = wp.media.editor.send.attachment;
            wp.media.editor.send.attachment = function(props, attachment) {
                var image_size =  props.size;

                var image_url = attachment.sizes[image_size].url;
                var insert_link = attachment.url;
                current.siblings(insertTo).html('<img src="'+image_url+'">');
                current.siblings(insertLink).val(insert_link);
                wp.media.editor.send.attachment = send_attachment_bkp;
            }
            wp.media.editor.open();
            return false;
        });

     

        $(document).on("click", ".tunna-design li", function(event)
        {
        	event.preventDefault();
        	var keyData = $(this).data("key");
        	
        	$(this).parent().find(".skin-active").removeClass("skin-active");
        	$(this).parent().next().attr("value", keyData);
        	$(this).addClass("skin-active");
        	
        })

        // $(".tunna-design").each(function()
        // {
        // 	var getVal = $(this).next().val();

        // 	if (getVal != '')
        // 	{
        // 		$(this).find(".skin-active").removeClass("skin-active");
        // 		$
        // 	}
        // })

	});

})(jQuery);	