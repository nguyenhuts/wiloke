<?php

/*
*Plugin Name: Tunna Slider
*Plugin Author: wiloke 
*Plugin URI : http://themeelite.com
*Author URI: http://wiloke.com
*Version: 1.0.1
*Description: Easily  to create a slider.
*/


define('WO_ADMIN_SLIDER_IMAGE', plugin_dir_url(__FILE__) . 'assets/images/');
define('WO_ADMIN_SLIDER_JS', plugin_dir_url(__FILE__) . 'assets/js/');
define('WO_ADMIN_SLIDER_CSS', plugin_dir_url(__FILE__) . 'assets/css/');


class woSlider
{
	const LANG = 'tunna_slider';
	public $aOptions;
	public function __construct()
	{
		// add_action('admin_menu', array($this, 'wo_hn_slider'));
		add_action('init', array($this, 'wo_register_post_type'));
		// add_action('admin_menu', array($this, 'wo_add_menu'));
		add_action('edit_form_after_title', array($this, 'wiloke_tunnar_slider_settings'));
		add_action('wp_ajax_add-slider', array($this, 'wo_create_form_slide'));
		add_action('save_post', array($this, 'wo_save_tunnar_slider'), 10, 2);
		add_action('add_meta_boxes', array($this, 'wo_metabox_additional'));
		// add_action('wp_enqueue_scripts', array($this, 'wo_admin_enqueue_scripts'));

		if ( is_admin() )
		{
			add_action('admin_enqueue_scripts', array($this, 'wo_slider_include_scripts'));
		}


		add_shortcode('tunna_slider', array($this, 'wo_tunna_shortcode'));
		
		// add_action('wp_head', array($this, 'wo_change_animate'));
	}	

	public function wo_admin_enqueue_scripts()
	{
		$url = plugin_dir_url(__FILE__);
		
		wp_register_script('plugin_supper_slides', $url . 'assets/js/jquery.superslides.min.js', array(), '0.6.4', true);
		wp_enqueue_script('plugin_supper_slides');
	}
	
	public function wo_change_animate()
	{
		
		// die();
		$aOptions = $this->getOptions();

		$time = isset($aOptions['speed']) && !empty($aOptions['speed']) ? ( (int)$aOptions['speed'])/1000 : 5;
		
	}
	
	public function getOptions()
	{	
		if ( isset($_GET['post']) && !empty($_GET['post']) )
		{
			$aOptions = get_post_meta($_GET['post'], "tunna_slider", true);
			
			if ( $aOptions && !is_array($aOptions) ) :
				$aOptions = urldecode($aOptions);
				$aOptions = unserialize($aOptions);
			endif;
		
			$this->aOptions = $aOptions;
		}
		
		return $this->aOptions;
	}	

	public function wo_metabox_additional()
	{
		
		// $this->getOptions();


		add_meta_box(
			'wo_effect',
			__( 'Effect', self::LANG ),
			array($this,'wo_slider_effect'),
			self::LANG,
			'side'
		);

	}

	//pagination
	public function wo_slider_pagination($post)
	{
		$choosen = isset($this->aOptions['pagination']) && !empty($this->aOptions['pagination']) ? $this->aOptions['pagination'] : false;
		?>
		<input type="checkbox" name="tunna_slider[pagination]" value="1" <?php checked($choosen, 1) ?>>
		<label for="wo-pagination">Pagination</label>	
		<?php 
	}


	//effect
	public function wo_slider_effect($post)
	{
		// $aOptions = $this;
		
		$choosen = isset($this->aOptions['effect']) && !empty($this->aOptions['effect']) ? $this->aOptions['effect'] : 'slide';
		$aSettings = array('fade', 'slide');
		?>
		<select name="tunna_slider[effect]">
			<?php 
				foreach ($aSettings as $key => $value)  :
					$selected = $value == $choosen ? 'selected' : '';
					?>
					<option value="<?php echo $value ?>" <?php echo $selected ?>><?php echo ucfirst($value) ?></option>
					<?php 
				endforeach;
			?>
		</select>
	
		
		<?php
	} 


	// shortcode
	public function wo_tunna_shortcode($atts)
	{
		$atts = shortcode_atts( array(
				'id' => '',
			), $atts );

		extract($atts);

		if ( empty($id) ) return "Please create a slider";

		$aData = get_post_meta($id, "tunna_slider", true);

		if ( $aData && !is_array($aData) )
		{
			$aData = urldecode($aData);
			$aData = unserialize($aData);
		}

		$effect = isset($aData['effect']) && !empty($aData['effect']) ? $aData['effect'] : 'fade';
	
		
		$slide = "";
		$slide .= '<div class="home-slider" data-background="bg-parallax">';
			$slide .='<div class="slides-container">';
				if ( isset($aData['settings']['img_url']) && !empty($aData['settings']['img_url']) ) :
			 		foreach ($aData['settings']['img_url'] as $k => $v) :
						if ( !empty($v) ) :
							$slide .='<div class="item">';
								$slide .='<img  src="'.$v.'">';
								$slide .= '<div class="tb">';
									$slide .= '<div class="home-media-content tb-cell text-center text-uppercase">';
										$title = isset($aData['settings']['title'][$k]) && !empty($aData['settings']['title'][$k]) ? stripslashes($aData['settings']['title'][$k]) : "";
										if ( !empty($title) ) :
											$slide .= '<h2 class="h1">'.$title.'</h2><hr class="he-divider">';
										endif;
										$slide .= isset($aData['settings']['description'][$k]) && !empty($aData['settings']['description'][$k])  ? '<p>' . stripslashes($aData['settings']['description'][$k]) . '</p>' : "";
									$slide .='</div>';
								$slide .='</div>';

							$slide .='</div>';
						endif;
					endforeach;
				endif;
			$slide .='</div>';
			$slide .='<nav class="slides-pagination"></nav>';
		$slide .= '</div>';

		$slide .= '<script type="text/javascript">';
			$slide .= "jQuery(document).ready(function(){";
		    $slide .= "jQuery('.home-slider').superslides({
		        animation: '".$effect."',
		        play: 5000,
		        pagination: true,
		        scrollable: true,
		        navigation: false
		    });";
			$slide .= '})';
			
		$slide .= '</script>';

		

		return $slide;
	}


	//save 
	public function wo_save_tunnar_slider($post_id)
	{
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;
		if (get_post_type($post_id) !== self::LANG ) return;

		if (!isset($_POST['post_type']) || self::LANG !== $_POST['post_type']) return;

		$settings = (isset($_POST['tunna_slider'])) ? $_POST['tunna_slider'] : array();

		$settings = serialize($settings);
		$settings = urlencode($settings);

		update_post_meta($post_id, "tunna_slider",$settings);
	}

	// ajax
	public function wo_create_form_slide()
	{
		sleep(1);
		$res = '<div class="accordion">
					<div class="accordion-wrap">
						<h3 class="accordion-toggle">
							<a class="right wo-delete-image" title="Delete layer" href="#">
								<i class="fa fa-times"></i>
							</a>
							<span>New Slide</span>
						</h3>
						<div class="accordion-content">
							<div class="container-12-fluid">
								<div class="large-6">
									<div class="image-wrap">
										<img src="'.plugin_dir_url(__FILE__) .'assets/images/no-img.jpg">
									</div>
									<br>
									<a class="btn btn-white upload-img" data-insertlink=".wo-insert-link" data-append=".image-wrap">Get image</a>
									<input type="hidden" name="tunna_slider[settings][img_url][]" class="wo-insert-link" value="">
								</div>
								<div class="large-6">
									<div class="editer">
										<div class="editor-wrap">
											<div class="edit-wrap">
												<h4 class="editer-title box-last">Title</h4>
												<div class="editer-content">
													<div class="form-group">			                    
								                        <div class="controls">
								                           <input type="text" name="tunna_slider[settings][title][]" value="" class="form-control">
								                        </div>
								                    </div>
												</div>
											</div> 
											<div class="edit-wrap">
												<h4 class="editer-title box-first">Description</h4>
												<div class="editer-content">
								                    <div class="form-group">
								                        <div class="controls">
								                          <textarea name="tunna_slider[settings][description][]"></textarea>
								                          <p class="help">Allow use tags: &lt;br>, &lt;i>, &lt;span>, &lt;strong></p>
								                        </div>
								                    </div>

												</div>
											</div> <!-- /edit-wrap -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>';
		echo $res;
		die();
	}


	//add menu
	public function wo_add_menu()
	{
		add_submenu_page('edit.php?post_type=tunna_slider', 'Settings', 'Tunna Slider', 'manage_options', 'tunna-slider-settings', array($this, 'wiloke_tunnar_slider_settings'));
	}



	// register post type
	public function wo_register_post_type()
	{
		$labels = array(
						'name'			=>'Tunna Slides', 
						'singular_name'	=>'Tunna Slide',
						'menu_name'	 	=>'Tunna Slider',
						'add_new'		=>'Create Slider',
						'add_new_item'	=> 'Add New Slideshow'
					);
		$args 	= array(
						'labels'				=> $labels,
						'public'				=> true,
						'publicly_queryable'	=> true,
						'rewrite'				=> array('slug'=>'tunna-slider'),
						'supports'				=> array('title'),
						'has_archive'			=> true,
						'hierarchical'			=> false,
						'capability_type'		=> 'post',
						'menu_icon'				=> 'dashicons-images-alt2'
			);
		register_post_type( 'tunna_slider', $args );
	}

	// public function wo_hn_slider()
	// {
	// 	$menuslider = add_menu_page('Wo Slider', 'Wo Slider', 'manage_options', 'wo-slider', array($this, 'wo_admin_slider_building'));
		
	// 	add_action('admin_print_styles-'.$menuslider, array($this, 'wo_slider_include_css'));
	// 	add_action('admin_print_scripts-'.$menuslider, array($this, 'wo_slider_include_js'));
	// }

	public function wiloke_tunnar_slider_settings()
	{
		global $post;

		$screen = get_current_screen();

		if ($screen->post_type != self::LANG) return;

		$this->getOptions();
		include ('hnslider_settings.php');
	}

	public function wo_slider_include_scripts()
	{

		$screen = get_current_screen();

		if ($screen->post_type == self::LANG) :
			wp_register_style('wo-slider-font', 'https://www.google.com/fonts#ChoosePlace:select/Collection:Open+Sans:400,600,700,800,300italic,400italic,300');
	        wp_register_style('wo-slider-grid', WO_ADMIN_SLIDER_CSS . 'grid.css');
	    	wp_register_style('wo-slider-cssui', WO_ADMIN_SLIDER_CSS . 'jquery-ui-1.10.4.custom.min.css');
	    	// wp_register_style('wo-slider-awe', WO_ADMIN_SLIDER_CSS . 'font-awesome.min.css');
	    	wp_register_style('wo-slider-style', WO_ADMIN_SLIDER_CSS . 'style.css');

	        wp_enqueue_style('wo-slider-font');
	        wp_enqueue_style('wo-slider-grid');
	    	wp_enqueue_style('wo-slider-cssui');
	    	// wp_enqueue_style('wo-slider-awe');
	    	wp_enqueue_style('wo-slider-style');

			
	    	wp_register_script('wo-jquery-uijs', WO_ADMIN_SLIDER_JS . 'jquery-ui-1.10.4.custom.min.js');
	    	wp_register_script('wo-slider-js', WO_ADMIN_SLIDER_JS . 'jquery.custom.js');

	    	wp_enqueue_script('jquery');
	    	wp_enqueue_media();
	    	wp_enqueue_script('media-upload');
	    	wp_enqueue_script('wo-jquery-uijs');
	    	wp_enqueue_script('wo-slider-js');

	    	wp_localize_script('wo-slider-js', 'WO_AJAX', array( 'ajax_url'=>admin_url('admin-ajax.php') ));

    	endif;

	}

	public function wo_slider_include_css()
	{
		// wp_register_style('wo-slider-style', WO_ADMIN_CSS . 'style.css', array(), '1.0');

		// wp_enqueue_style('wo-slider-style');


		
	}


}

$init = new woSlider();