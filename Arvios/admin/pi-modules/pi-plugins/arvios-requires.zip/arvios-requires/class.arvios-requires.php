<?php 

/*
Plugin Name: Arvios  Requires
Plugin Author: wiloke
Plugin URI: http://wiloke.com
Author URI: http://wiloke.com
Version: 1.0
Description: Arvios Functionally
*/

define('piArviosAssetsUrl', plugin_dir_url(__FILE__) . 'admin/assets/');
define('piArviosAdminDir', plugin_dir_path(__FILE__) . 'admin/');

class piArviosFunctionally
{
	
	public function __construct()
	{	
		$this->pi_arvios_modules_init();

		add_shortcode('pi_text_slider', array($this, 'pi_text_slider'));
	}

    public function pi_text_slider($atts)
    {
        $atts = shortcode_atts( array(
            'title'         =>  'We are Wiloke', 'We Love What We do',
            'description'   =>  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur diam felis, lacinia eget<br> mattis ut, mollis id turpis class aptent tacit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur diam felis, lacinia eget<br> mattis ut, mollis id turpis class aptent tacit',
            'img'           =>  'http://placehold.it/1600x1160',
            'effect'        =>  'fade'
        ), $atts );

        ob_start();
        ?>
        <?php 
            if ( !preg_match("/http/", $atts['img']) )
            {
                if ( !wp_attachment_is_image($atts['img']) )
                {
                    _e('<h2 class="alert alert-danger">Broken image, please re-upload</h2>', piCore::LANG);
                }else{
                ?>
                <div class="bg-parallax" style="background-image:  url('<?php echo wp_get_attachment_url($atts['img'])  ?>')"></div>
                <div class="bg-overlay"></div>
                <?php
                } 
            }else{
            ?>
                <div class="bg-parallax" style="background-image:  url('<?php echo esc_url($atts['img']);  ?>')"></div>
                <div class="bg-overlay"></div>
            <?php 
            }
        ?>
        

        <div class="text-slider" data-effect="<?php echo esc_attr($atts['effect']) ?>">
        <?php 
            $aTitle = explode(",", $atts['title']);
            $aDes   = explode(",", $atts['description']);
            foreach ( $aTitle as $k => $title ) :
        ?>
            <div class="item">
                <div class="tb">
                    <div class="home-media-content tb-cell text-center">
                        <h2 class="h1"><?php printf( __('%s', piCore::LANG), wp_unslash($title) ); ?></h2>
                        <hr class="he-divider">
                        <p><?php printf( __('%s', piCore::LANG), wp_unslash($aDes[$k]) ); ?></p>
                    </div>
                </div>
            </div>
        <?php 
            endforeach;
        ?>
        </div>

        <script type="text/javascript">
        var $effect = jQuery(".text-slider").data("effect");
        jQuery('.home-media, .text-slider .item').height(jQuery(window).height());
        jQuery(".text-slider").owlCarousel(
        {
            autoPlay: 5000,
            navigation: false,
            slideSpeed: 200,
            singleItem: true,
            transitionStyle: $effect,
            pagination: false,
            navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right "></i>']
        });
       
        </script>
        <?php 
        $content = ob_get_clean();
        return $content;
    }

	public function pi_arvios_modules_init()
	{
		$fileName = array("class.pi_portfolio.php", "class.pi_skills.php",  "class.pi_aboutus.php",  "class.pi_services.php", "class.pi_ourteam.php", "class.pi_ourclients.php", "class.pi_fact.php", "class.pi_pricingtable.php", "class.pi_testimonial.php");

		$piPath = plugin_dir_path(__FILE__) . 'admin/pi-modules/';

		foreach ($fileName as $file)
		{
			include ($piPath .  'pi-taxonomy/' . $file);
		}

        include ($piPath .  'pi-shortcodes/class.shortcodes.php');



		/*=========================================*/
		/* Portfolio
		/*=========================================*/
		$piPortfolio 	= new piPortfolio();
	

		/*=========================================*/
		/* Skill
		/*=========================================*/
		$piSkills  		 = new piSkills();
		

		/*=========================================*/
		/* About us
		/*=========================================*/
		$piAboutUs 		 = new piAboutUs();
	
		/*=========================================*/
		/* Services
		/*=========================================*/
		$piServices 	 = new piServices();
	

		/*=========================================*/
		/* Our team
		/*=========================================*/
		$piOurteam 	     = new piOurteam();
		

		/*=========================================*/
		/* Our Clients
		/*=========================================*/
		$piOurClients 	= new piOurclients();

        /*=========================================*/
        /* piFunFact
        /*=========================================*/
        $piFunFacts      = new piFunFacts();

        /*=========================================*/
        /* piFunFact
        /*=========================================*/
        $piPricingTable      = new piPricingTable();

        /*=========================================*/
        /* piTestimonial
        /*=========================================*/
        $piTestimonial      = new piTestimonial();

        /*=========================================*/
        /* piWilokeShortcodes
        /*=========================================*/
        $piWilokeShortcodes      = new piWilokeShortcodes();
        
	}

	public function pi_arvios_unslashed_before_update($data)
	{
		$data = is_array($data) ? array_map(array($this,'pi_arvios_unslashed_before_update'), $data) : wp_unslash($data);
    	return $data;
	}
}

$init = new piArviosFunctionally();