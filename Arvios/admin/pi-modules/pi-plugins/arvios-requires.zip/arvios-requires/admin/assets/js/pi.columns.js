;(function($, window, document, undefined)
{
	"use strict";


	tinymce.PluginManager.add('pi_columns', function( editor, url ) 
	{
		editor.addButton( 'pi_columns', {
			text: 'Folio Columns',
			icon: ARVIOSASSETURL + 'img/columns.png',
			type: 'menubutton',
			menu: 
			[
				{
					text: 'Full Width',
					onclick: function()
					{
						piInsertIntoWpEditor('fullwidth');
					}
				},
				{	
					text: 'Two Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('twocolumns');
					},
				},
				
				{	
					text: 'Three Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('threecolumns');
					},
				},
				{	
					text: 'Four Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('fourcolumns');
					},
				}
			]
		});
	});

	function piInsertIntoWpEditor(column)
	{
		var shortCodeVisual = "";
		switch ( column )
		{
			case 'fullwidth':
				shortCodeVisual = "[pi_folio_col width='1/1'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]";
				break;

			case 'twocolumns':
				shortCodeVisual = "[pi_folio_col type='1/2'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col] <br>[pi_folio_col type='1/2'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]";
				break;

			case 'threecolumns':
				shortCodeVisual = "[pi_folio_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col] <br>[pi_folio_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]<br>[pi_folio_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]";
				break;

			case 'fourcolumns':
				shortCodeVisual = "[pi_folio_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col] <br>[pi_folio_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]<br>[pi_folio_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col] <br> [pi_folio_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_folio_col]";
				break;
		}

		/* get the TinyMCE version to account for API diffs */
		var tmce_ver = window.tinyMCE.majorVersion;

		if (tmce_ver >= 4) {
		 window.tinyMCE.execCommand('mceInsertContent', false, shortCodeVisual);
		} else {
		 window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, shortCodeVisual);
		}

		// $('.wp-editor-area#content').insertAtCaret(shortCodeText, '');
	}




})(jQuery, window, document)