;(function($, window, document, undefined)
{
	"use strict";

	$(document).ready(function()
	{
		$(".form-table").on("click", ".pi-add-offer", function(event)
		{
			event.preventDefault();
			var $offer = "";
			var $getName = "";
				$getName = $(this).attr("data-key");

				$offer += '<div class="pi-wrap-offer-item">';
					$offer += '<input class="form-control pi-offer-item" type="text" placeholder="" name="pi_pricingtable['+$getName+'][offers][]" value="">';
					$offer += '<a class="pi-remove-offer dashicons dashicons-trash" href="#"></a>';
				$offer += '</div>';
				$(this).before($offer);
		})

		$(".form-table").on("click", ".pi-remove-offer", function(event)
		{
			event.preventDefault();
			$(this).parent().remove();
		})
	})
})(jQuery, window, document)