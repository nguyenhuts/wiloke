<?php 
$atts = shortcode_atts(
	array(
		'type' 			=> '1/1',
	),
	$atts
);

switch ($atts['type']) 
{
	case '1/2':
		$class = "col-md-6";
		break;
	
	case '1/3':
		$class = "col-md-4";
		break; 

	case '1/4':
		$class = "col-md-3";
		break;

	default:
		$class = "col-md-12";
		break;
}

$output .= '<div class="col-xs-12  col-sm-6 '.$class.'">'.do_shortcode($content).'</div>';

return $output;