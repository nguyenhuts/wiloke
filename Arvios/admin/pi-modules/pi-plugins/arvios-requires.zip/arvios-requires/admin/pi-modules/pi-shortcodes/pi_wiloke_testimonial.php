<?php 


$atts = shortcode_atts(
	array(
		'items' 			=> 5,
		'autoplay'			=> true,
		'duration'			=> 1000,
		'speed'				=> 3000,
		'testimonial'		=> ''
	), 
	$atts
);


if ( empty($atts['testimonial']) )
{
	return '<p class="alert alert-danger text-center">Please choose a testimonial</p>';
}

$getTestimonial = get_post_meta($atts['testimonial'], '_pi_testimonial', true);

ob_start();
?>	

<div class="footerTop" data-autoPlay="<?php echo $atts['autoplay'] ?>" data-speed="<?php echo $atts['speed'] ?>" data-items="<?php echo $atts['items'] ?>" data-duration="<?php echo $atts['duration'] ?>" data-delay="<?php echo $atts['duration'] ?>">
	<?php 
		if ( $getTestimonial )
		{
			$tes  = "";
			?>
			<div class="fc mf-content-image"> 
				<div class="mf-list-image imageSlide">
					<?php 
					foreach ( $getTestimonial as $key => $aTestimonial )
					{
						$tes .= '<li class="mf-caption">';
					        $tes .= '<h3 class="font-openBold">';
						        if( isset($aTestimonial['testimonial']) )
						        { 
						          	$tes .= wp_unslash($aTestimonial['testimonial']);
						        }
					        $tes .= '</h3>';
					        $tes .= '<h4>';
						        if( isset($aTestimonial['author']) )
						        {
						        	$tes .=wp_unslash($aTestimonial['author']);
						        }
					        $tes .='</h4>';
					    $tes .= '</li>';
						?>
						<div class="mf-image imageBox"><?php echo isset($aTestimonial['photo']) ? wp_get_attachment_image($aTestimonial['photo'], 'pi-testimonial-thumbnail') : ""; ?></div>
						<?php 
					}
					?>
					<div class="mf-control">
			            <div class="mf-btn-control mf-button-prev"><i class="fa fa-chevron-left"></i></div>
			            <div class="mf-btn-control mf-button-next"><i class="fa fa-chevron-right"></i></div>
		        	</div>
				</div>
			</div>
			<div class="footerTopContent clearfix">
				<ul class="slides testimonialText list-unstyled mf-list-caption">
				<?php print $tes;  ?>
				</ul>
			</div>
			<?php 
		}
	?>
</div>
<?php
$output = ob_get_clean();


