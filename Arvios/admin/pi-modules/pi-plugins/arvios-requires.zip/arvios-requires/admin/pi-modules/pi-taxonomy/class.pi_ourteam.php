<?php

class piOurteam extends piArviosFunctionally 
{
    public function __construct()
    {
        add_action('init', array($this, 'register_ourteam'));
        add_action('add_meta_boxes', array($this,'pi_create_ourteam_settings'), 10, 2 );
        add_action('save_post', array($this, 'pi_save_data'));
        add_action('admin_enqueue_scripts', array($this, 'pi_enqueue_scripts'));
    }

    public function pi_save_data($postID)
    {
        if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
         
        if  ( $_POST['post_type'] == 'pi_ourteam' ) :
            $data = isset($_POST['ourteam']) ? $_POST['ourteam'] : array();
            $data = $this->pi_arvios_unslashed_before_update($data);
            update_post_meta($postID, "_pi_ourteam", $data);
        endif;
    }

    public function register_ourteam()
    {
        $teAboutus  =   array
                            (   
                                'labels'            => array('name'=>_x('Our Team', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Team', 'Post type genereal name', 'wiloke')),
                                'hierarchical'      => true,
                                'public'            => true,
                                'has_archive'       => false,
                                'rewrite'           => array('slug'=>'our-team', 'with_front'=>false),
                                'supports'          => array('title'),
                                'can_export'        => true,
                                'menu_icon'         => 'dashicons-groups',
                                'show_ui'           => true,
                                'exclude_from_search'=>true
                            );
        register_post_type('pi_ourteam', $teAboutus);
    }


    public function pi_enqueue_scripts()
    {
        global $typenow;
        if ($typenow == 'pi_ourteam') :
            wp_register_style('pi_plugin_fontawesome', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
            wp_enqueue_style("pi_plugin_fontawesome");

            wp_register_style("pi_ourteam", piArviosAssetsUrl . "css/pi.ourteam.css", array(), "1.0");
            wp_enqueue_style("pi_ourteam");
        endif;

    }

    public function pi_create_ourteam_settings()
    {
       

        add_meta_box
        ( 
            'pi-ourteam',
            __( 'Our Team', 'wiloke' ),
            array($this, 'pi_ourteam'),
            'pi_ourteam',
            'normal',
            'default'
        );

    }


   

    public function pi_ourteam()
    {
        global $post;
        $aDef = array
        (
            "ourteam"=>array
                            (
                                'enable_ourteam' => 1,
                                0 => array
                                    (
                                        "photo"=>"",
                                        // "to"=>"",
                                        "name"=>"",
                                        // "des"=>"",
                                        "position"=>"",
                                        "intro" =>"",
                                        "social_link" => array()
                                    ),

                            )
        ); 

        $aSocialNetworks = array("facebook"=>"fa fa-facebook","twitter"=> "fa fa-twitter","googleplus"=> "fa fa-google-plus", "linkedin"=> "fa fa-linkedin", "dribbble"=>"fa fa-dribbble", "youtube"=>"fa fa-youtube", "vimeo"=>"fa fa-vimeo-square", "behance"=>"fa fa-behance");

        $aOurteam = get_post_meta($post->ID, "_pi_ourteam", true);


        $aOurteam = $aOurteam ? $aOurteam : $aDef['ourteam'];

        // $enable = $aOurteam['']
        
        ?>
        <div class="panel-body">
                <table class="form-table">  
                    <tbody>
                <?php 
                    if ( isset($aOurteam['enable_ourteam']) )
                    {
                        array_shift($aOurteam);
                    }
                    
                    foreach ($aOurteam as $k => $aData) :
                ?>
                        <!-- <div class="container-12-row exp-row pi-delete panel-body"> -->
                        <tr class="table-row tab-item pi-parent">
                            <td>
                                <a href="#" class="pi-toggle inner is_active" data-target=".pi_accordion" data-method="next"><i class="fa fa-minus-square-o"></i></a>
                                <div class="pi-wrap-content pi_accordion">

                                    <div class="clearfix pi-group"> 
                                        <div class="pi-label">
                                            <label><?php _e('Photo', 'wiloke') ?></label>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <div class="form-avatar">
                                                <a class="upload-image js_upload" href="#" data-insertto=".lux-gallery" data-method="html" data-use="find">
                                                    <div class="lux-gallery pi-aboutme is-border-none">
                                                        <img src="<?php echo !empty($aData['photo'])  ? wp_get_attachment_url($aData['photo']) : piArviosAssetsUrl . 'images/addpeople.png'; ?>">
                                                    </div>
                                                </a>
                                                <input type="hidden" value="<?php echo $aData['photo'] ?>" name="ourteam[<?php echo $k ?>][photo]">
                                                <?php if ( !empty($aData['photo'] ) ) : ?>
                                                <button class="button pi-button button-primary js_remove_image siblings" data-placeholder="<?php echo piArviosAssetsUrl . 'images/addpeople.png'; ?>">Remove</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>  

                                    <div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Name', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <input name="ourteam[<?php echo $k ?>][name]" value="<?php echo $aData['name'] ?>" class="text-field" type="text">
                                        </div>
                                    </div>

                                    <div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Position/Skill', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                           <input name="ourteam[<?php echo $k ?>][position]" value="<?php echo $aData['position'] ?>" class="text-field" type="text">
                                        </div>
                                    </div>

                                    <!-- <div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Small Intro', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <textarea name="ourteam[<?php echo $k ?>][intro]" cols="30" rows="10"><?php echo esc_textarea($aData['intro']) ?></textarea>
                                        </div>
                                    </div> -->

                                    <div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Social Networks', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <?php 
                                                $aSocialLink = isset($aData['social_link']) ? $aData['social_link']  : '';

                                                foreach ( $aSocialNetworks as $name => $icon )
                                                {
                                                    $name = trim($name);
                                                    ?>
                                                    <div class="wrap-icon">
                                                        <a class="pi-icon pi-thickbox" href="Javascript:void(0)">
                                                            <i class="<?php echo $icon ?>"></i>
                                                        </a>
                                                        <input class="text-field pi-social-link" type="text"  name="ourteam[<?php echo $k ?>][social_link][<?php echo $name ?>]" value="<?php echo isset($aSocialLink[$name])  ? ($aSocialLink[$name]) : ''; ?>" placeholder="Social Link">
                                                        <input class="text-field pi-social-icon" type="hidden"  name="ourteam[<?php echo $k ?>][social_icon][<?php echo $name ?>]" value="<?php echo esc_attr($icon);  ?>">
                                                    </div>
                                                    <?php
                                                }
                                            ?>
                                        </div>
                                    </div>

                                    <a class="pi-button button button-primary   pi-detele-tab" data-count=".row-item"  href="JavaScript:void(0)"><?php _e('Remove', 'wiloke') ?></a>
                                            
                                </div>                              
                            </td>
                        </tr>
                            
                <?php 
                endforeach;
                ?>
                        <tr class="table-row pi-wrap-add">
                            <td class="wrap-add-tabs">
                                <a href="JavaScript:void(0)" class="pi-button button-primary button pi-add-tabs" data-name="ourteam" data-img="<?php  echo  piArviosAssetsUrl . 'images/addpeople.png';   ?>"><?php _e('Add New', 'wiloke') ?></a>
                            </td>
                        </tr>

                    </tbody>
                </table>
         </div>
        <?php 
    }


}