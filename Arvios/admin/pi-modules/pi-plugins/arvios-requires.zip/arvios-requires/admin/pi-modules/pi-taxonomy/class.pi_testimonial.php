<?php

class piTestimonial extends piArviosFunctionally 
{
	public function __construct()
	{
		add_action('init', array($this, 'register_testimonial'));
		add_action('add_meta_boxes', array($this,'pi_create_testimonial_settings'), 10, 2 );
		add_action('save_post', array($this, 'pi_save_data'));
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueu_scripts'));
	}
 
	public function pi_save_data($postID)
	{   
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
         
        if  ( $_POST['post_type'] == 'pi_testimonials' ) :
        	$data  = isset($_POST['pi_testimonials']) ? $_POST['pi_testimonials'] : array();
        	$data = $this->pi_arvios_unslashed_before_update($data);
	    	update_post_meta($postID, "_pi_testimonials", $data);
    	endif;
	} 

	public function register_testimonial()
	{
		$teAboutus 	= 	array
							(	
								'labels' 			=> array('name'=>_x('Testimonials', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Testimonial', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'testimonials', 'with_front'=>false),
						        'supports'          => array('title'),
						        'can_export'        => true,
						        'exclude_from_search'=>true,
						        'menu_icon'         => 'dashicons-format-status',
						        'show_ui'           => true,
					    	);
		register_post_type('pi_testimonials', $teAboutus);
	}


	public function pi_enqueu_scripts()
	{
		global $typenow;

		if ($typenow == 'pi_testimonials') :
			wp_register_style('pi_plugin_fontawesome', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
			wp_enqueue_style("pi_plugin_fontawesome");
			
			wp_register_style("pi_aboutus", piArviosAssetsUrl . "css/pi.ourteam.css", array(), "1.0");
			wp_enqueue_style("pi_aboutus");

			wp_register_style('pi_skill', piArviosAssetsUrl . 'css/pi.skill.css', array(), '1.0');
			wp_enqueue_style('pi_skill');
			wp_enqueue_script('jquery-ui-slider');

			wp_register_script('pi_plugin_easypiechar', piArviosAssetsUrl . 'js/jquery.easypiechart.js', array(), '2.1.1', true);
			wp_enqueue_script('pi_plugin_easypiechar');

			wp_register_script('pi_skills', piArviosAssetsUrl . 'js/pi.skills.js', array(), '1.0', true);
			wp_enqueue_script('pi_skills');
			
		endif;
	}

	public function pi_create_testimonial_settings()
	{

        add_meta_box( 
            'pi-testimonials',
            __( 'Testimonials', 'wiloke' ),
            array($this, 'pi_tetimonials'),
            'pi_testimonials',
            'normal',
            'default'
        );


	}


	public function pi_tetimonials()
	{
		global $post;
		$aDef = array
		(
			"pi_testimonials"=>array
							(	
								0 => array
									(
										"author"=>"",
										"website"=>"",
										"testimonial" =>""
									),

							)
		); 

		$aTestimonial = get_post_meta($post->ID, "_pi_testimonials", true);
		$aTestimonial = $aTestimonial ? $aTestimonial : $aDef['pi_testimonials'];

		?>

			<div class="panel-body">
				<table class="form-table">	
					<tbody>
						<?php 
							foreach ($aTestimonial as $k => $aData) :
						?>
							<tr class="table-row tab-item pi-parent">
								<td>
									<a href="#" class="pi-toggle inner is_active" data-target=".pi_accordion" data-method="next"><i class="fa fa-minus-square-o"></i></a>
									<div class="pi-wrap-content pi_accordion">

										<div class="clearfix pi-group">
											<div class="pi-label">
												<label class="form-label"><?php _e('Testimonial', 'wiloke') ?></label>
											</div>
											<div class="pi-wrapsettings">
												<textarea name="pi_testimonials[<?php echo $k ?>][testimonial]"  cols="30" rows="10"><?php echo esc_textarea($aData['testimonial']) ?></textarea>
											</div>
										</div>

										<div class="clearfix pi-group">
											<div class="pi-label">
												<strong><?php _e('Author', 'wiloke') ?></strong>
											</div>
										 	<div class="pi-wrapsettings">
												<input name="pi_testimonials[<?php echo $k ?>][author]" value="<?php echo isset($aData['author']) ? esc_attr($aData['author']) : ''; ?>" type="text">
											</div>
										</div>

										<div class="clearfix pi-group">
											<div class="pi-label">
												<strong><?php _e('website', 'wiloke') ?></strong>
											</div>
										 	<div class="pi-wrapsettings">
												<input name="pi_testimonials[<?php echo $k ?>][website]" type="text" value="<?php echo isset($aData['website']) ? esc_attr($aData['website']) : ''; ?>">
											</div>
										</div>

										<a class="button button-primary   pi-detele-tab" data-count=".row-item"  href="JavaScript:void(0)"><?php _e('Remove', 'wiloke') ?></a>
												
									</div>								
								</td>
							</tr>	
					 	<?php 
					 		endforeach;
					 	?>
				 			<tr class="table-row pi-wrap-add">
								<td class="wrap-add-tabs">
									<a href="JavaScript:void(0)" class="button button-primary fullwidth pi-add-tabs" data-name="pi_testimonials" data-img="<?php  echo  piArviosAssetsUrl . 'images/addpeople.png';   ?>"><?php _e('Add New', 'wiloke') ?></a>
								</td>
							</tr>
		 			</tbody>
				</table>
		 </div>
	<?php
	}

}