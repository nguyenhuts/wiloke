<?php 
$atts = shortcode_atts(
	array( 
		'alert' 			=> 'This is danger alert!',
		'contextual'	  	=> 'alert-danger'
	),
	$atts
);

$output .= '<div class="alert '.$atts['contextual'].'" role="alert">'.wp_unslash($atts['alert']).'</div>';

return $output;