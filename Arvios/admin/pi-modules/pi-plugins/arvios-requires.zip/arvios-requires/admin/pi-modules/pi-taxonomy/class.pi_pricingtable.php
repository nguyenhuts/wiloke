<?php 

class piPricingTable extends piArviosFunctionally
{
    public function __construct()
    {
        add_action('init', array($this, 'register_pricingtable'));
        add_action('add_meta_boxes', array($this,'pi_create_pricingtable_settings'), 10, 2 );
        add_action('save_post', array($this, 'pi_save_data'));
        add_action('admin_enqueue_scripts', array($this, 'pi_enqueue_scripts'));
    }

    public function pi_save_data($postID)
    {
        if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
         
        if  ( $_POST['post_type'] == 'pi_pricingtable' ) :
            $data = isset($_POST['pi_pricingtable']) ? $_POST['pi_pricingtable'] : array();
            $data = $this->pi_arvios_unslashed_before_update($data);
            update_post_meta($postID, "_pi_pricingtable", $data);
        endif;
    }

    public function register_pricingtable()
    {
        $teAboutus  =   array
                            (   
                                'labels'            => array('name'=>_x('Pricing Table', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Pricing Table', 'Post type genereal name', 'wiloke')),
                                'hierarchical'      => true,
                                'public'            => true,
                                'has_archive'       => false,
                                'rewrite'           => array('slug'=>'pricingtable', 'with_front'=>false),
                                'supports'          => array('title'),
                                'can_export'        => true,
                                'menu_icon'         => 'dashicons-admin-settings',
                                'show_ui'           => true,
                                'exclude_from_search'=>true
                            );
        register_post_type('pi_pricingtable', $teAboutus);
    }


    public function pi_enqueue_scripts()
    {
        global $typenow;

        if ($typenow == 'pi_pricingtable') :
            wp_register_style('pi_plugin_fontawesome', get_template_directory_uri() . '/admin/pi-assets/css/font-awesome.min.css', array(), '4.0.2');
            wp_enqueue_style("pi_plugin_fontawesome");
            wp_register_style("pi_pricingtable", piArviosAssetsUrl . "css/pi.pricingtable.css", array(), "1.0");
            wp_enqueue_style("pi_pricingtable");

            wp_register_script("pi_pricingtable", piArviosAssetsUrl . "js/pi.pricingtable.js", array(), "1.0", true);
            wp_enqueue_script("pi_pricingtable");
        endif;
    }

    public function pi_create_pricingtable_settings()
    {
        add_meta_box
        ( 
            'pi-pricingtable',
            __( 'Pricing Table', 'wiloke' ),
            array($this, 'pi_pricingtable'),
            'pi_pricingtable',
            'normal',
            'default'
        );
    }


   

    public function pi_pricingtable()
    {
        global $post;
        $aDef = array
        (
            "pricingtable"=>array
                            (
                                0=>array(
                                    "title"			=>	"",
                                    "currency"		=>	"",
                                    "price" 		=>	"",
                                    "duration" 		=> 	"",
                                    "offers"		=> array(0=>'Your offer'),
                                    "button_name"	=> "",
                                    "url"			=> ""
                                )
                            )
        ); 

   

        $aPricingtable = get_post_meta($post->ID, "_pi_pricingtable", true);


        $aPricingtable = $aPricingtable ? $aPricingtable : $aDef['pricingtable'];

        ?>
        <div class="panel-body">


                <div class="fl-wrapper">
                	<div class="container-12-fluid pi_append_here form-table">
    	                <?php 
    	                    $max = count($aPricingtable);
    	                    foreach ($aPricingtable as $k => $aData) :
    	                ?>
	       				<div class="pi-parent medium-4 te-delete pi-delete">
				 			<div class="form-group">
				 				<label class="form-label"><b><?php _e('Title', 'wiloke'); ?></b></label>
				 				<div class="controls">
									<input class="form-control pi-required" type="text" value="<?php echo esc_attr($aData['title']); ?>" name="pi_pricingtable[<?php  echo $k ?>][title]" placeholder="Basic">
								</div>
				 			</div>
				 			<div class="form-group">
				 				<label class="form-label"><b><?php _e('Currency', 'wiloke'); ?></b></label>
				 				<div class="controls">
									<input class="form-control pi-required" type="text" value="<?php echo esc_attr($aData['currency']); ?>" name="pi_pricingtable[<?php  echo $k ?>][currency]" placeholder="$">
								</div>
				 			</div>

				 			<div class="form-group">
				 				<label class="form-label"><b><?php _e('Price', 'wiloke'); ?></b></label>
				 				<div class="controls">
									<input class="form-control pi-required" type="text" value="<?php echo esc_attr($aData['price']); ?>" name="pi_pricingtable[<?php  echo $k ?>][price]" placeholder="">
								</div>
				 			</div>

				 			<div class="form-group">
				 				<label class="form-label"><b><?php _e('Duration', 'wiloke'); ?></b></label>
				 				<div class="controls">
									<input class="form-control pi-required" type="text" value="<?php echo esc_attr($aData['duration']); ?>" name="pi_pricingtable[<?php  echo $k ?>][duration]" placeholder="per month">
								</div>
				 			</div>
							
							<div class="form-group">
								<label class="form-label"><b><?php _e('Offers', 'wiloke'); ?></b></label>
				 				<div class="controls">
					 			<?php 
					 				if ( count($aData['offers']) > 0 )
					 				{
					 					foreach ( $aData['offers'] as $offer ) 
					 					{
					 					?>
										<div class="pi-wrap-offer-item">
											<input class="form-control pi-offer-item" type="text" value="<?php echo esc_attr($offer); ?>" name="pi_pricingtable[<?php  echo $k ?>][offers][]" placeholder="">
											<a class="pi-remove-offer dashicons dashicons-trash" href="#"></a>
										</div>
					 					<?php 
					 					}
					 				}
					 			?>
					 			<button class="pi-add-offer button button-primary" href="#" data-key="<?php echo esc_attr($k); ?>">Add Offer</button>
				 				</div>
				 			</div>

                            <div class="form-group">
                                <label class="form-label"><b><?php _e('Button Name', 'wiloke'); ?></b></label>
                                <div class="controls">
                                    <input class="form-control" type="text" value="<?php echo isset($aData['button_name']) ? esc_attr($aData['button_name']) : ''; ?>" name="pi_pricingtable[<?php  echo $k ?>][button_name]" placeholder="sign up">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label"><b><?php _e('Button Url', 'wiloke'); ?></b></label>
                                <div class="controls">
                                    <input class="form-control" type="text" value="<?php echo isset($aData['url']) ? esc_url($aData['url']) :''; ?>" name="pi_pricingtable[<?php  echo $k ?>][url]" placeholder="your link">
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="controls">
                                    <label class="form-label">
                                        <input class="form-control" type="checkbox" value="1" name="pi_pricingtable[<?php  echo $k ?>][highlight]" <?php echo isset($aData['highlight']) ? 'checked' : ''; ?>>
                                        <b><?php _e('High light', 'wiloke'); ?></b>
                                    </label>
                                </div>
                            </div>


							<a class="pi-delete-item" data-hasrequired="true" title="Delete" href="#">
								<i class="dashicons dashicons-no"></i>
							</a>
						</div>		
    	                <?php 
    	           	 		endforeach;
    	                ?>
                    </div>
                  	<div class="pi-wrap-add container-12-row pi_wrap_button">
				 		<a href="JavaScript:void(0)" data-hasrequired="true" data-type="pricing" class="button-primary button fullwidth  pi_addmore" data-message="Please fill required fields" data-currentmaxorder="<?php echo ($max) ?>"><?php _e('Add New', 'wiloke'); ?></a>
				 	</div>
				</div>
                  
         </div>
        <?php 
    }
}