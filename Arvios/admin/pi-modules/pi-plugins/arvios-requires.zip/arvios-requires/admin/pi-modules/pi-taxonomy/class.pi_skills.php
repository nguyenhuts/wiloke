<?php

class piSkills extends piArviosFunctionally
{
	public function __construct()
	{
		add_action('init', array($this, "register_skills"));
		add_action('add_meta_boxes', array($this, 'pi_create_skill_settings'), 10, 2);
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueue_scripts'));
		add_action('save_post', array($this, 'pi_save_data'));
	}

	public function pi_enqueue_scripts()
	{
		global $typenow; 

		if ($typenow == 'pi_skill') : 
			wp_register_style('pi_skill', piArviosAssetsUrl . 'css/pi.skill.css', array(), '1.0');
			wp_enqueue_style('pi_skill');
			wp_enqueue_script('jquery-ui-slider');

			wp_register_script('pi_plugin_easypiechar', piArviosAssetsUrl . 'js/jquery.easypiechart.js', array(), '2.1.1', true);
			wp_enqueue_script('pi_plugin_easypiechar');

			wp_register_script('pi_skills', piArviosAssetsUrl . 'js/pi.skills.js', array(), '1.0', true);
			wp_enqueue_script('pi_skills');
		endif;
	}

	public function pi_save_data($postID)
	{
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
        
        if  ( $_POST['post_type'] == 'pi_skill' ) :
        
			$data  = isset($_POST['pi_skill']) ? $_POST['pi_skill'] : array();
        	$data = $this->pi_arvios_unslashed_before_update($data);
	    	update_post_meta($postID, "_pi_skill", $data);

    	endif;
	}

	public function pi_create_skill_settings()
	{
		add_meta_box
		( 
            'pi-skills',
            __( 'Skills', 'wiloke' ),
            array($this, 'pi_skills_builder'),
            'pi_skill',
            'normal',
            'default'
        );
	}
 
		public function pi_skills_builder()
	{
		global $post;

		$aDef = array
				(
					'pi_skill'=>array
									(	
										'enable_skill' => 1,
										0	   =>	array(
														'percent'=>50, 
														'skill'  =>'Wordpress',
														
														)
									)
				);
		

		$piaSkills = get_post_meta($post->ID, '_pi_skill', true);

		

		$piaSkills = $piaSkills ? $piaSkills  : $aDef['pi_skill'];

		$piaSkills = $piaSkills && is_array($piaSkills) ? $piaSkills : array();

		$max = count($piaSkills);

		?>
		<div class="fl-wrapper">
			<div class="container-12-fluid">

			
				<div id="pi_skills" class="container-12-row pi_append_here">
				<?php 

				if ( isset($piaSkills['enable_skill']) )
				{
					array_shift($piaSkills);
				}

				foreach ($piaSkills as $k => $aData) :
					$piSliderId = uniqid("pi_slider_");
				?>
				
			 		<div class="medium-4 pi-delete">
	 					<div class="pi-form">
	 						<a class="skill-del del-exp-btn pi-delete-item" href="#" title="Delete"><i class="dashicons dashicons-no"></i></a>
	 						<div class="pi_charts" data-percent="<?php echo $aData['percent'] ?>"><span class="percent"><?php echo $aData['percent'] ?>%</span></div>
	 						<div id="<?php echo $piSliderId ?>" class="pi_slider"></div>
 							<script type="text/javascript">
 							jQuery(document).ready(function(){
 								jQuery("#<?php echo $piSliderId ?>").slider(
 								{
 									min: 0, 
 									max: 100, 
 									value: <?php echo $aData['percent'] ?>, 
 									// stop: function(event, ui)
 									// {
 									// 	jQuery(this).next().next().attr("value", ui.value);
 									// 	jQuery(this).prev().data('easyPieChart').update(ui.value);
 									// 	jQuery(this).prev().find(".percent").text(ui.value + '%');
 									// },
 									change: function(event, ui)
 									{
 										jQuery(this).next().next().attr("value", ui.value);
 										jQuery(this).prev().data('easyPieChart').update(ui.value);
 										jQuery(this).prev().find(".percent").text(ui.value + '%');
 									}
 								});
 							})
	 						</script>
			 				<input type="text" class="pi_skill_value" name="pi_skill[<?php echo $k ?>][percent]" placeholder="Percent" value="<?php echo esc_attr($aData['percent']) ?>">  <br>
			 				<input type="text" class="" name="pi_skill[<?php echo $k ?>][skill]" placeholder="Skill" value="<?php echo esc_attr($aData['skill']) ?>">  <br>
			 				

				 		</div>
			 		</div>	
			 	
				<?php 
				endforeach;
				?>
				</div>

				<div class="container-12-fluid pi_wrap_button">
					<div class="container-12-row">
		 				<div class="medium-12">
	 						<button  type="button" class="button button-primart pi_addmore fl-btn-top" data-type="skill" data-currentmaxorder="<?php echo ($max) ?>">Add</button>
		 				</div>	
		 			</div>
				</div>

			</div>
		</div>
		<?php 
	}

	public function register_skills()
	{
		$piSkills 	= 	array
							(	
								'labels' 			=> array('name'=>_x('Skills', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Skill', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'skill', 'with_front'=>false),
						        'supports'          => array('title'),
						        'can_export'        => true,
						        'menu_icon'         => 'dashicons-yes',
						        'exclude_from_search'=>true,
						        'show_ui'           => true,
					    	);

		register_post_type('pi_skill', $piSkills);

	}
}