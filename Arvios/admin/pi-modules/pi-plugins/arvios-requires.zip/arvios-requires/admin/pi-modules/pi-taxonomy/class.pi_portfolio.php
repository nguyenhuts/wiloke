<?php

class piPortfolio extends piArviosFunctionally
{
	public function __construct()
	{
		add_action('init', array($this, "pi_register_portfolio"));
		add_action('add_meta_boxes', array($this, 'pi_create_settings'));
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueue_scripts'));
		add_action('save_post', array($this, 'pi_save_data'));
	}

	public function pi_save_data($postID)
	{
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
         
        if  ( $_POST['post_type'] == 'pi_portfolio' ) : 
        
        	$data = isset($_POST['pi_portfolio']) ? $_POST['pi_portfolio'] : array();
	    	update_post_meta($postID, "_pi_portfolio", $data);

    	endif;
	}
 
	public function pi_enqueue_scripts()
	{
		global $typenow;
 
		if ($typenow == 'pi_portfolio')
		{
			
			wp_register_style('pi_plugin_fa', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
			wp_enqueue_style('pi_plugin_fa');
			
			wp_register_style('pi_portfolio', piArviosAssetsUrl . 'css/pi.portfolio.css', array(), '1.0');
			wp_enqueue_style('pi_portfolio');

			wp_register_script('pi_add_video', piArviosAssetsUrl . 'js/pi.add_video.js', array(), '1.0', true);
			wp_enqueue_script('pi_add_video');

			wp_register_script('pi_flickr', piArviosAssetsUrl . 'js/jflickrfeed.min.js', array(), '1.0', true);
			wp_enqueue_script('pi_flickr');

			wp_register_script('pi_portfolio', piArviosAssetsUrl . 'js/pi.portfolio.js', array(), '1.0', true);
			wp_enqueue_script('pi_portfolio');
		}
	}

	public function pi_create_settings()
	{
		add_meta_box
		(
			'pi-porfolio',
			__('Portfolio Header', 'wiloke'),
			array($this, 'pi_setting_builder'),
			'pi_portfolio',
			'normal',
			'default'
		);
	}

	public function pi_setting_builder()
	{
		global $post;

		// $aDefault  = array('link'=>'#', 'image_id'=>'', 'media_type'=>'gallery', 'video_type'=>'', 'video_id'=>'', 'video_link'=>'', 'video_poster'=>'', 'flickr_id'=>'', 'flickr_limit'=>'', 'flickr_image_size'=>'', 'flickr_get_data'=>'');
		$aDefault  = array('image_id'=>'', 'media_type'=>'gallery', 'video_link'=>'');
		$aPorfolio = get_post_meta($post->ID, '_pi_portfolio', true);
		$instance = !empty($aPorfolio) ? $aPorfolio : $aDefault;


	?>

    	<div class="container-12-fluid">
			<div class="container-12-row">
				<div class="large-12">
					<div class="body">
						
	              		<select name="pi_portfolio[media_type]" class="pi_media_type">
	                    	<option value="video" data-target=".js_add_video" data-hide=".js_add_gallery, .js_add_flickr" <?php selected($instance['media_type'], 'video') ?>><?php _e('Vimeo/Youtube', 'wiloke'); ?></option>
	                    	<option value="gallery" data-target=".js_add_gallery" data-hide=".js_add_video, .js_add_flickr" <?php selected($instance['media_type'], 'gallery') ?>><?php _e('Slider/Image', 'wiloke'); ?></option>
	                    </select> 

	               	 	<div class="form-group gallery-wrapper js_add_video">
	                    	<div class="controls wrap-upload bg-action">
	                    		<input type="text" name="pi_portfolio[video_link]" class="pi_add_video pi_of_video" value="<?php echo !empty($instance['video_link']) ? esc_url($instance['video_link']) : ''; ?>" placeholder="Video Link">
	                    	</div>
	                    </div>

	                    <div class="form-group gallery-wrapper js_add_gallery">
	                 	    <ul class="lux-gallery">
	                    		<?php 
	                    			if ( isset($instance['image_id']) && !empty($instance['image_id']) )  : 
	                    				$parse = explode(",", $instance['image_id']);
	                    				foreach ($parse as $id)
	                    				{
	                    					?>
	                    					<li class="attachment img-item width-300" data-id="<?php echo $id; ?>">
	                    						<?php 
                    								echo  wp_get_attachment_image($id, 'thumbnail'); 
	                    						?>
												<a class="pi-remove" href="#">
													<i class="fa fa-times"></i>
												</a>
											</li>
	                    					<?php 
	                    				}
	                    			endif;
	                    		?>
	                    	</ul>
	                    	
	                    	<div class="controls wrap-upload bg-action">
	                    		<input type="button" data-func="siblings" data-target=".lux-gallery" class="blue-btn btn btn-info upload-image multiple	 js_upload" value="Upload">
	                    		<input type="text" class="box-image-id" name="pi_portfolio[image_id]" value="<?php echo isset($instance['image_id']) ? esc_attr($instance['image_id']) : $instance['image_id']; ?>">
	                    	</div>
	                    	
	                    </div>
					</div>
				</div>
			</div>
		</div>
		
	<?php 
	}

	public function pi_register_portfolio()
	{
		$piPortfolio 	= 	array
							(	
								'labels' 			=> array('name'=>_x('Porfolio', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Porfolio', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'query_var'			=> true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'porfolio', 'with_front'=>false),
						        'supports'          => array('title', 'thumbnail', 'editor', 'comments'),
						        'can_export'        => true,
						        'menu_icon'         => 'dashicons-list-view',
						        'show_ui'           => true,
					    	);

		$piPortfolioCats = array
						(
                            'hierarchical'  =>  true,
                            'labels'        =>  array('name' =>_x('Portfolio Categories', 'post type general name', 'wiloke') ),
                            'query_var'     =>  true,
                            'rewrite'       =>  array('with_front' => false, 'hierarchical' =>false, 'slug' => 'porfolio-cats')               
						);	
		

		register_post_type('pi_portfolio', $piPortfolio);
		register_taxonomy('pi_portfolio_cats', 'pi_portfolio', $piPortfolioCats);			
		register_taxonomy('portfolio_skill',array('pi_portfolio'), array(
		    'hierarchical' => false,
		    'label' => __('Tags', 'wiloke'),
		    'show_ui' => true,
		    'show_in_menu' => true,
		    'show_in_nav_menus' =>  false,
		    'show_in_nav'   => false,
		    'show_admin_column' => false,
		    'query_var' => true,
		    'rewrite' => array( 'slug' => 'portfolio_skill' ),
		));			
	}
}
