(function($, document, window, undefined)
{
	"use strict";
			
	// If the shortcode use image placeholder, the name of image placeholder is matched with id of this shortcode
	
	$.PISC = $.PISC || {};	

	$.PISC = function()
	{
		var $defaults = 
		{
			prefix : 'pi_',
			buttonID : 'pi_shortcodes_button',
			imgUrl   : PIIMGURL
		}
		
		var $buttons = 
		[
			{
				id: 'alert',
				title: 'Alert',
				popup: true,
				img: 'alerts.png'
			},
			{
				id: 'button',
				title: 'Button',
				img: 'button.png',
				popup: true
			},
			{
				id: 'progress',
				title: 'Progress Bar',
				img: 'progressbar.png',
				popup: true,
			},
			{
				id: 'quote',
				title: 'Quote',
				img: 'blockquote.png',
				popup: true,
			},
			{
				id: 'panel',
				title: 'Panel',
				img: 'boxes.png',
				popup: true,
			},
			// {
			// 	id: 'tabs',
			// 	title: 'Tabs',
			// 	img: 'tabs.png',
			// 	popup: true,
			// },
			// {
			// 	id: 'accordion',
			// 	title: 'Accordion',
			// 	img: 'accordion.png',
			// 	popup: true,
			// },
			{	
				id: 'customcontent',
				title: 'Custom Content',
				img: 'boxes.png',
				popup: true,
			},
			{
				id: '4_columns',
				title: '4 Columns',
				img: '4col.png',
				popup: false,
				generateHtml: function(obj){
					return '[pi_wiloke_col type="1/4"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/4"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/4"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/4"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]';
				},
			},
			{
				id: '3_columns',
				title: '3 Columns',
				img: '3col.png',
				popup: false,
				generateHtml: function(obj){
					return '[pi_wiloke_col type="1/3"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/3"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/3"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]';
				},
			},
			{
				id: '2_columns',
				title: '2 Columns',
				img: '2col.png',
				popup: false,
				generateHtml: function(obj){
					return '[pi_wiloke_col type="1/2"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type="1/2"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]';
				},
			},
			{
				id: 'fullwidth',
				title: 'Full Width',
				img: 'full.png',
				popup: false,
				generateHtml: function(obj){
					return '[pi_wiloke_col width="1/1"] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]';
				},
			}
		]
		
		this.options = $defaults;
		this.buttons = $buttons;
		this.ed = {};

		this.init();
	}

	$.PISC.prototype = 
	{
		init: function()
		{
			
			var _self = this,
				$leng = this.buttons.length,
				allowRuning = false;		

	   		tinymce.create("tinymce.plugins.pi_shortcodes_customizer", 
	  		{
		  		init: function(ed, url)
		  		{
		  			for ( var i = 0; i < $leng ; i++ )
		  		   	{	  		   	
		  		   		_self.create_button(_self.buttons[i], ed);
		  			}     
	  	 		}
		  	});

		  	tinymce.PluginManager.add('pi_shortcodes_in_customizer', tinymce.plugins.pi_shortcodes_customizer);
		},


		create_button: function(oInfo, ed)
		{
			var _self = this;

			ed.addButton( this.options.prefix + oInfo.id,
			{
				title: oInfo.title,
				image: _self.options.imgUrl + oInfo.img,
				onclick: function()
				{
					if (oInfo.popup)
					{
						_self.dialog(oInfo);				
					}else{
						ed.execCommand('mceInsertContent', true, oInfo.generateHtml());
					}
				}
			});	
		},

		dialog: function(_oInfo)
		{
			var _self = this, $wrapShortcode = $("#pi-wrap-shortcode"), _shorcode, $title, _getSettings  = "", $wrapEditor = $("#pi-custom-section-popup");
		 	_shorcode = _oInfo.id;
		 	$title 	= _oInfo.title;

			$wrapEditor.addClass("hidden");
			$wrapShortcode.removeClass("hidden");
			$(".pi-shortcode-settings").css({display:'none'}).removeClass("active");
			$wrapShortcode.find("#pi-"+_shorcode+"-sc").css({display: 'block'});

			$("#pi-insert-shortcode").click(function()
			{
				var _children="", _children_name="";
				if ( _shorcode == 'tabs' || _shorcode == 'accordion' )
				{
					_children_name = _shorcode == 'tabs' ? 'pi_tab' : 'pi_item';

					$("#pi-"+_shorcode+"-sc .pi-item").each(function()
					{
						_children += '[' + _children_name +' ';

						$(this).find(".form-control").each(function()
						{
							_children +=  $(this).attr("name") + '="' + $(this).val() + '" ';
						})

						_children = _children.trim();

						_children += ']';
					})

					_getSettings = '[pi_wiloke_'+_shorcode+']' + _children + '[/pi_wiloke_'+_shorcode+']';
				}else{
					$("#pi-"+_shorcode+"-sc .form-control").each(function()
					{
						_getSettings += $(this).attr("name") + '="' + $(this).val() + '" ';
					})

					if ( _getSettings !='' )
					{
						_getSettings = '[pi_wiloke_'+_shorcode+" " + _getSettings.trim()+']';
					}else{
						_getSettings = '[pi_wiloke_'+_shorcode+']';
					}
				}
				/* get the TinyMCE version to account for API diffs */
				var tmce_ver = window.tinyMCE.majorVersion;

				if (tmce_ver >= 4)
				{
			 		window.tinyMCE.execCommand('mceInsertContent', false, _getSettings);
				}else{
			 		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, _getSettings);
				}
				_getSettings = "";

				

				_self.pi_clear_something();

				$wrapShortcode.addClass("hidden");
				$wrapEditor.removeClass("hidden");

				return false;
			})
			
			$("#pi-cancel-shortcode").click(function(){
				_self.pi_clear_something();
				$wrapShortcode.addClass("hidden");
				$wrapEditor.removeClass("hidden");
				return false;
			})


			switch ( _shorcode )
			{
				case 'progress':
					_self.piPreviewProgressBar();
					break;
				case 'button':
					_self.piPreviewButton();
					break;
				case 'quote':
					_self.piPreviewQuote();
					break;
				case 'alert':
					_self.piPreviewAlert();
					break;
				case 'panel':
					_self.piPreviewPanel();
					break;
				case 'tabs':
					_self.piAddTabs();
					break;
				case 'accordion':
					_self.piAddAccordion();
					break;
			}
		},
		pi_clear_something: function()
		{
			$("#pi-insert-shortcode").unbind('click');
			document.getElementById("pi-reset").reset();
			$("#pi-reset").find(".is_clone").remove();
			$(".pi-addtabs").unbind("click");
			$(".pi-addaccordion").unbind("click");
		},
		

		piPreviewProgressBar: function()
		{
			var $progressBar = $("#pi-progress-sc .pi-preview .progress-bar");
			$("#pi-progress-sc [name='percent']").change(function()
			{
				$progressBar.css({width: $(this).val() + "%"});
			});

			$("#pi-progress-sc [name='active']").change(function()
			{
				$progressBar.toggleClass("active");
			});

			$("#pi-progress-sc [name='striped']").change(function()
			{
				$progressBar.toggleClass("progress-bar-striped");
			});

			$("#pi-progress-sc [name='contextual']").change(function()
			{
				$progressBar.removeClass("progress-bar-success progress-bar-danger progress-bar-info progress-bar-warning");
				$progressBar.addClass("progress-bar-"+$(this).val());
			});
		},

		/*Tabs*/
		piAddTabs: function()
		{
			$(".wrap-setting").fadeIn();
			$(".pi-addtabs").click(function()
			{
				var _clone 		= "",
					$statHere   = $(this).parent();
					$(".wrap-setting").fadeOut();
					_clone 		= $statHere.prev().clone();
					_clone.find("[name='title']").val("Tab title");
					_clone.find("[name='content']").text("Tab content");
					_clone.find(".wrap-setting").fadeIn();
					_clone.addClass("is_clone");
					$statHere.before(_clone);

				return false;
			})

			$("#pi-tabs-sc").on("click", ".pi-removetab", function(event)
			{
				event.preventDefault();
				if ( $(this).closest(".pi-shortcode-settings").find(".pi-item").length > 1 )
				{
					$(this).closest(".pi-item").remove();
				}else{
					alert("Oop, You need at least one item");
				}
			})
		},

		/*Accordion*/
		piAddAccordion: function()
		{
			$(".wrap-setting").fadeIn();
			$(".pi-addaccordion").click(function()
			{
				var _clone 		= "",
					$statHere   = $(this).parent();
					_clone 		= $statHere.prev().clone();
					_clone.find("[name='title']").val("Title");
					_clone.find("[name='content']").text("Content");
					_clone.addClass("is_clone");
					
					$statHere.before(_clone);
				return false;
			})

			$("#pi-accordion-sc").on("click", ".pi-removeitem", function(event)
			{
				event.preventDefault();
				if ( $(this).closest(".pi-shortcode-settings").find(".pi-item").length > 1 )
				{
					$(this).closest(".pi-item").remove();
				}else{
					alert("Oop, You need at least one item");
				}
			})
		},

		piPreviewButton: function()
		{
			var $button = $("#pi-button-sc .pi-preview .btn");

			$("#pi-button-sc [name='button_name']").change(function()
			{
				$button.html($(this).val());
			});

			$("#pi-button-sc [name='contextual']").change(function()
			{
				$button.removeClass("btn-primary btn-success btn-danger btn-info btn-warning");
				$button.addClass($(this).val());
			});	

			$("#pi-button-sc [name='size']").change(function()
			{
				$button.removeClass("btn-sm btn-lg btn-default");
				$button.addClass($(this).val());
			});	

			$("#pi-button-sc [name='size']").change(function()
			{
				$button.removeClass("btn-default btn-small btn-lg");
				$button.addClass($(this).val());
			});	
		},

		piPreviewQuote: function()
		{
			var $quote = $("#pi-quote-sc .pi-preview blockquote");

			$("#pi-quote-sc [name='quote']").keyup(function()
			{
				$quote.find("p").html($(this).val());
			});

			$("#pi-quote-sc [name='author']").keyup(function()
			{
				$quote.find("cite").html($(this).val());
			});	
		},

		piPreviewAlert: function()
		{
			var $alert = $("#pi-alert-sc .pi-preview .alert");

			$("#pi-alert-sc [name='alert']").keyup(function()
			{
				$alert.html($(this).val());
			});

			$("#pi-alert-sc [name='contextual']").change(function()
			{
				$alert.removeClass("alert-success alert-danger alert-info alert-warning");
				$alert.addClass($(this).val());
			});	
		},
		
		piPreviewPanel: function()
		{
			var $panel = $("#pi-panel-sc .pi-preview .panel");

			$("#pi-panel-sc [name='title']").keyup(function()
			{
				$panel.find(".panel-title").html($(this).val());
			});

			$("#pi-panel-sc [name='content']").keyup(function()
			{
				$panel.find(".panel-body").html($(this).val());
			});	

			$("#pi-panel-sc [name='contextual']").change(function()
			{
				$panel.removeClass("panel-primary panel-success panel-danger panel-info panel-warning");
				$panel.addClass($(this).val());
			});	
		}
	}

	$(document).ready(function()
	{
		new $.PISC();
		var $doc = $(document);
		/*Toggle Slide*/
		$doc.on("click", ".pi-item-toggle .dashicons", function(){
			$(this).next().toggle();
		})
	});
	
})(jQuery, document, window)	
