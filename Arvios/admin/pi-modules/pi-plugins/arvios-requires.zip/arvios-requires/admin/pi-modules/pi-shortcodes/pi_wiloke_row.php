<?php 

$output .= '<div class="row">'.do_shortcode($content).'</div>';

return $output;