<?php

class piAboutUs extends piArviosFunctionally 
{
	public function __construct()
	{
		add_action('init', array($this, 'register_aboutus'));
		add_action('add_meta_boxes', array($this,'pi_create_about_settings'), 10, 2 );
		add_action('save_post', array($this, 'pi_save_data'));
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueu_scripts'));
	} 

	public function pi_save_data($postID)
	{
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
        
        if  ( $_POST['post_type'] == 'pi_aboutus' ) :
        	$data  = isset($_POST['aboutus']) ? $_POST['aboutus'] : array();
        	$data = $this->pi_arvios_unslashed_before_update($data);
	    	update_post_meta($postID, "_pi_aboutus", $data);
    	endif;
	}

	public function register_aboutus()
	{
		$piAboutus 	= 	array
							(	
								'labels' 			=> array('name'=>_x('About Us', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('About Us', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'about-us', 'with_front'=>false),
						        'supports'          => array('title'),
						        'can_export'        => true,
						        'menu_icon'         => 'dashicons-groups',
						        'show_ui'           => true,
						        'exclude_from_search'=>true
					    	);
		register_post_type('pi_aboutus', $piAboutus);
	}


	public function pi_enqueu_scripts()
	{
		global $typenow;

		if ($typenow == 'pi_aboutus') :

			wp_register_style('pi_plugin_fontawesome', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
			wp_enqueue_style("pi_plugin_fontawesome");
			
			
			wp_register_style("pi_aboutus", piArviosAssetsUrl . "css/pi.ourteam.css", array(), "1.0");
			wp_enqueue_style("pi_aboutus");
			
		endif;

	}

	public function pi_create_about_settings()
	{
		add_meta_box
		( 
            'pi-aboutus',
            __( 'Intro', 'wiloke' ),
            array($this, 'pi_about_builder'),
            'pi_aboutus',
            'normal',
            'default'
        );

	}



	public function pi_about_builder()
	{
		global $post;		
		$aAboutus 	= get_post_meta($post->ID, "_pi_aboutus", true);
		$piAboutUs 	= !empty($aAboutus) ? $aAboutus : array(0=> array('photo'=>'', 'title'=>'', 'intro'=>'', 'button'=>'', 'link'=>''));
		?>
	        <div class="panel-body">
                <table class="form-table">  
                    <tbody>
						<?php 
						foreach ($piAboutUs as $k => $aData) : 
							$intro  = isset($aData['intro']) ? utf8_decode($aData['intro']) : "";
						?>
						<tr class="table-row tab-item pi-parent">
							<td>
								<a href="#" class="pi-toggle inner is_active" data-target=".pi_accordion" data-method="next"><i class="fa fa-minus-square-o"></i></a>
								<div class="pi-wrap-content pi_accordion">
									<div class="clearfix pi-group">
										<div class="pi-label">
											<label><?php _e('Image', 'wiloke') ?></label>
										</div>
										<div class="pi-wrapsettings">

											<div class="form-avatar">
												<a class="upload-image js_upload" href="#" data-insertto=".lux-gallery" data-method="html" data-use="find">
													<div class="lux-gallery pi-aboutme is-border-none">
														<img  src="<?php echo !empty($aData['photo'])  ? esc_url(wp_get_attachment_url($aData['photo'])) : piArviosAssetsUrl . 'images/placeholder.gif'; ?>" alt="<?php echo get_post_meta($aData['photo'], '_wp_attachment_image_alt', true) ?>">
													</div>
												</a> 

												<input type="hidden" value="<?php echo $aData['photo'] ?>" name="aboutus[<?php echo $k; ?>][photo]">
												<?php if ( !empty($aData['photo'] ) ) : ?>
												<button class="button pi-button button-primary js_remove_image siblings" data-placeholder="<?php echo piArviosAssetsUrl . 'images/placeholder.gif'; ?>"><?php _e('Remove', 'wiloke'); ?></button>
												<?php endif; ?>
											</div>
										</div>
									</div>
									<div class="clearfix pi-group">
										<div class="pi-label">
											<label><?php _e('Title', 'wiloke') ?></label>
										</div>

										<div class="pi-wrapsettings">
											<input type="text" name="aboutus[<?php echo $k; ?>][title]" value="<?php echo isset($aData['title']) ? ($aData['title']) : ""; ?>">
										</div> 
									</div>
									<div class="clearfix pi-group pi-has-editor">
										<div class="pi-label">
											<label class="form-label"><?php _e('Small Intro', 'wiloke') ?></label>
										</div>
										<div class="pi-wrapsettings">
											<textarea name="aboutus[<?php echo $k; ?>][intro]" class="form-control" rows="6"><?php echo wp_unslash($intro); ?></textarea>
										</div>
									</div>
									<div class="clearfix pi-group pi-has-editor">
										<div class="pi-label">
											<label class="form-label"><?php _e('Link To', 'wiloke') ?></label>
										</div>
										<div class="pi-wrapsettings">
											<input type="text" name="aboutus[<?php echo $k; ?>][button]" value="<?php echo isset($aData['button']) ? ($aData['button']) : ""; ?>" placeholder="Button"> <br>
											<input type="text" name="aboutus[<?php echo $k; ?>][link]" value="<?php echo isset($aData['link']) ? ($aData['link']) : ""; ?>" placeholder="Link">
										</div>
									</div>
									<a class="pi-button button button-primary pi-detele-tab" data-count=".row-item"  href="JavaScript:void(0)"><?php _e('Remove', 'wiloke') ?></a>
								</div>
							</tr>
						</tr>
						<?php endforeach; ?>
			 			<tr class="table-row pi-wrap-add">
                            <td class="wrap-add-tabs">
                                <a href="JavaScript:void(0)" class="pi-button button-primary button pi-add-tabs" data-name="aboutus" data-img="<?php  echo  piArviosAssetsUrl . 'images/placeholder.gif';   ?>"><?php _e('Add New', 'wiloke') ?></a>
                            </td>
                        </tr>

                    </tbody>
                </table>
         </div>
					
		<?php 
	}


}