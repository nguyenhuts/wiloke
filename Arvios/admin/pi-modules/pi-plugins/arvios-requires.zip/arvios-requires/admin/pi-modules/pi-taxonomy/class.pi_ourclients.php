<?php

class piOurClients extends piArviosFunctionally 
{
	public function __construct()
	{
		add_action('init', array($this, 'register_ourclients'));
		add_action('add_meta_boxes', array($this,'pi_create_about_settings'), 10, 2 );
		add_action('save_post', array($this, 'pi_save_data'));
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueu_scripts'));
	}
 
	public function pi_save_data($postID)
	{   
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
        
         
        if  ( $_POST['post_type'] == 'pi_ourclients' ) :
        	$data  = isset($_POST['pi_ourclients']) ? $_POST['pi_ourclients'] : array();
        	$data = $this->pi_arvios_unslashed_before_update($data);
	    	update_post_meta($postID, "_pi_ourclients", $data);
    	endif;
	} 

	public function register_ourclients()
	{
		$teAboutus 	= 	array
							(	
								'labels' 			=> array('name'=>_x('Clients', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Client', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'our-clients', 'with_front'=>false),
						        'supports'          => array('title'),
						        'can_export'        => true,
						        'menu_icon'         => 'dashicons-smiley',
						        'show_ui'           => true,
						        'exclude_from_search'=>true
					    	);
		register_post_type('pi_ourclients', $teAboutus);
	}


	public function pi_enqueu_scripts()
	{
		global $typenow;

		if ($typenow == 'pi_ourclients') :
			wp_register_style('pi_plugin_fontawesome', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
			wp_enqueue_style("pi_plugin_fontawesome");
			
			wp_register_style("pi_aboutus", piArviosAssetsUrl . "css/pi.ourteam.css", array(), "1.0");
			wp_enqueue_style("pi_aboutus");

			wp_register_style('pi_skill', piArviosAssetsUrl . 'css/pi.skill.css', array(), '1.0');
			wp_enqueue_style('pi_skill');
			wp_enqueue_script('jquery-ui-slider');

			wp_register_script('pi_plugin_easypiechar', piArviosAssetsUrl . 'js/jquery.easypiechart.js', array(), '2.1.1', true);
			wp_enqueue_script('pi_plugin_easypiechar');

			wp_register_script('pi_skills', piArviosAssetsUrl . 'js/pi.skills.js', array(), '1.0', true);
			wp_enqueue_script('pi_skills');
			
		endif;

	}

	public function pi_create_about_settings()
	{
       	add_meta_box( 
            'pi-ourclients',
            __( 'Clients', 'wiloke' ),
            array($this, 'pi_clients'),
            'pi_ourclients',
            'normal',
            'default'
        );
	}

	public function pi_clients()
	{
		global $post;
		$aDef = array
		(
			"pi_ourclients"=>array
							(
								0 => array
									(
										"photo"=>"",
										'client'=>"",
										'small_intro'=>"",
										"website" =>""
									),

							)
		); 

		$aClients = get_post_meta($post->ID, "_pi_ourclients", true);
		$aClients = $aClients ? $aClients : $aDef['pi_ourclients'];


	  
		?>
		 <table class="form-table">  
            <tbody>
                <?php
		         	$max = count($aClients);
                    foreach ($aClients as $k => $aData) :
                ?>
                        <!-- <div class="container-12-row exp-row pi-delete panel-body"> -->
                        <tr class="table-row tab-item pi-parent">
                            <td>
                                <a href="#" class="pi-toggle inner is_active" data-target=".pi_accordion" data-method="next"><i class="fa fa-minus-square-o"></i></a>
                                <div class="pi-wrap-content pi_accordion">

                                    <div class="clearfix pi-group"> 
                                        <div class="pi-label">
                                            <label><?php _e('Photo', 'wiloke') ?></label>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <div class="form-avatar">
                                                <a class="upload-image js_upload" href="#" data-insertto=".lux-gallery" data-method="html" data-use="find">
                                                    <div class="lux-gallery pi-ourclient is-border-none">
                                                        <img  src="<?php echo !empty($aData['photo'])  ? wp_get_attachment_url($aData['photo']) : "http://placehold.it/250x150"; ?>">
                                                    </div>
                                                </a>
                                                <input type="hidden" value="<?php echo $aData['photo'] ?>" name="pi_ourclients[<?php echo $k ?>][photo]">
                                                <?php if ( !empty($aData['photo'] ) ) : ?>
                                                <button class="button pi-button button-primary js_remove_image siblings" data-placeholder="http://placehold.it/250x150">Remove</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>  
									
									<div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Client', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <input name="pi_ourclients[<?php echo $k ?>][client]" value="<?php echo isset($aData['client']) && !empty($aData['client']) ? esc_attr($aData['client']) :''; ?>" class="text-field" type="text" placeholder="Your client name">
                                        </div>
                                    </div>

                                    <div class="clearfix pi-group">
                                        <div class="pi-label">
                                            <strong><?php _e('Link', 'wiloke') ?></strong>
                                        </div>
                                        <div class="pi-wrapsettings">
                                            <input name="pi_ourclients[<?php echo $k ?>][link]" value="<?php echo isset($aData['link']) && !empty($aData['link']) ? esc_url($aData['link']) :''; ?>" class="text-field" type="text">
                                        </div>
                                    </div>
                                 
                                    <a class="pi-button button button-primary   pi-detele-tab" data-count=".row-item"  href="JavaScript:void(0)"><?php _e('Remove', 'wiloke') ?></a>
                                            
                                </div>                              
                            </td>
                        </tr>     
                <?php 
                	endforeach;
                ?>
                <tr class="table-row pi-wrap-add">
                    <td class="wrap-add-tabs">
                        <a href="JavaScript:void(0)" class="pi-button button-primary button pi-add-tabs" data-name="pi_ourclients" data-img="http://placehold.it/250x150"><?php _e('Add New', 'wiloke') ?></a>
                    </td>
                </tr>
            </tbody>
        </table>
		<?php
	}

}