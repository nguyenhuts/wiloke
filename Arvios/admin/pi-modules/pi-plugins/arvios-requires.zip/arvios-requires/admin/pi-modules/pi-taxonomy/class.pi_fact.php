<?php
 
class piFunFacts extends piArviosFunctionally 
{
	public function __construct()
	{
		add_action('init', array($this, 'register_funfact'));
		add_action('add_meta_boxes', array($this,'pi_create_fact_settings'), 10, 2 );
		add_action('save_post', array($this, 'pi_save_data'));
		add_action('admin_enqueue_scripts', array($this, 'pi_enqueu_scripts'));
	}
 
	public function pi_save_data($postID)
	{   
		if (!current_user_can('edit_post', $postID) ) return;

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        if ( !isset($_POST['post_type']) || empty($_POST['post_type']) ) return;
         
        if  ( $_POST['post_type'] == 'pi_funfacts' ) :
        	$data  = isset($_POST['pi_funfacts']) ? $_POST['pi_funfacts'] : array();
        	$data = $this->pi_arvios_unslashed_before_update($data);
	    	update_post_meta($postID, "_pi_funfacts", $data);
    	endif;
	} 

	public function register_funfact()
	{
		$teAboutus 	= 	array
							(	
								'labels' 			=> array('name'=>_x('Fun Facts', 'Post type genereal name', 'wiloke'), 'singular_name'=>_x('Client', 'Post type genereal name', 'wiloke')),
						        'hierarchical'      => true,
						        'public'            => true,
						        'has_archive'       => false,
						        'rewrite'           => array('slug'=>'fun-facts', 'with_front'=>false),
						        'supports'          => array('title'),
						        'can_export'        => true,
						        'menu_icon'         => 'dashicons-share-alt',
						        'show_ui'           => true,
						        'exclude_from_search'=>true
					    	);
		register_post_type('pi_funfacts', $teAboutus);
	}


	public function pi_enqueu_scripts()
	{
		global $typenow;

		if ($typenow == 'pi_funfacts') :
			wp_register_style('pi_plugin_fontawesome', piArviosAssetsUrl . 'css/font-awesome.min.css', array(), '4.0.2');
			wp_enqueue_style("pi_plugin_fontawesome");
			
			wp_register_style('pi_services', piArviosAssetsUrl . 'css/pi.skill.css', array(), '1.0');
			wp_enqueue_style('pi_services');
		endif;

	}

	public function pi_create_fact_settings()
	{
       	add_meta_box
		( 
            'pi-funfacts',
            __( 'Fun Facts', 'wiloke' ),
            array($this, 'pi_fact_builder'),
            'pi_funfacts',
            'normal',
            'default'
        );
	}

	public function pi_fact_builder()
	{
		global $post;
		$aDef = array
		(
			"pi_funfact"=>array
							(
								0 => array
									(
										"name"			=>	"",
										"total"			=>	"",
										"icon"			=>	"fa fa-refresh",
									),

							)
		);

		$aFunFacts = get_post_meta($post->ID, "_pi_funfacts", true);
		$aFunFacts = $aFunFacts ? $aFunFacts : $aDef['pi_funfact'];

		$max = count($aFunFacts);
		?>
		<div class="fl-wrapper">
			<div class="container-12-fluid">
				<div class="container-12-row pi_append_here">
					<?php 
					foreach ($aFunFacts as $k => $aData) :
					?>
					
				 		<div class="medium-4 pi-delete te-delete pricing-table">
		 					<div class="pi-form">
		 						<a class="skill-del pi-delete-item del-exp-btn" href="#" title="Delete"><i class="dashicons dashicons-no"></i></a>
					 			<a href="#" class="js_add_icon"><i class="<?php echo esc_attr($aData['icon']) ?>"></i></a>
					 			<input type="hidden" title="Icon" class="pi_title" name="pi_funfacts[<?php echo $k ?>][icon]" placeholder="Icon" value="<?php echo esc_attr($aData['icon']) ?>">
					 			<input type="text" class="pi_title" title="Ex: any numbers" name="pi_funfacts[<?php echo $k ?>][total]" placeholder="Ex: any numbers" value="<?php echo esc_attr($aData['total']) ?>">  
					 			<textarea class="pi_des" name="pi_funfacts[<?php echo $k ?>][name]" placeholder="Ex: Coffe Cups, Awwards"><?php echo esc_textarea($aData['name']) ?></textarea>
					 		</div>
				 		</div>	
				 	
					<?php 
					endforeach;
					?>
				</div>

				<div class="container-12-fluid pi_wrap_button">
					<div class="container-12-row">
		 				<div class="medium-12">
	 						<button  type="button" class="button pi_addmore fl-btn-top" data-type="fact" data-currentmaxorder="<?php echo ($max) ?>">Add</button>
		 				</div>	
		 			</div>
				</div>

			</div>
		</div>
		<?php
	}

}