<?php

Class piWilokeShortcodes 
{
 
    public $aKills = array();
    public $aweShortcodes = array();

    public $aGroup = array();

    public $aButtons = array("pi_4_columns", "pi_3_columns", "pi_2_columns", "pi_fullwidth",   "pi_progress", "pi_button", "pi_quote", "pi_alert", "pi_panel", "pi_tabs", "pi_accordion", "pi_customcontent");

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'pi_enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'pi_wiloke_enqueue_scripts'));
        
        add_action('admin_head', array($this, 'pi_wiloke_add_mce_button') );

        add_action('customize_controls_print_scripts', array($this, 'pi_shortcodes_in_customizer') );


        add_action('admin_footer', array($this, 'pi_shortcode_settings'));

        add_shortcode('pi_wiloke_portfolio', array($this, 'pi_wiloke_portfolio'));
        add_shortcode('pi_wiloke_blog', array($this, 'pi_wiloke_blog'));
        add_shortcode('pi_wiloke_contact', array($this, 'pi_wiloke_contact'));
        add_shortcode('pi_wiloke_testimonial', array($this, 'pi_wiloke_testimonial'));
        add_shortcode('pi_tab', array($this, 'pi_tab'));
        add_shortcode('pi_wiloke_tabs', array($this, 'pi_wiloke_tabs'));
        add_shortcode('pi_wiloke_accordion', array($this, 'pi_wiloke_accordion'));
        add_shortcode('pi_item', array($this, 'pi_item'));
        add_shortcode('pi_wiloke_progress', array($this, 'pi_wiloke_progress'));
        add_shortcode('pi_wiloke_alert', array($this, 'pi_wiloke_alert'));
        add_shortcode('pi_wiloke_quote', array($this, 'pi_wiloke_quote'));
        add_shortcode('pi_wiloke_button', array($this, 'pi_wiloke_button'));
        add_shortcode('pi_wiloke_panel', array($this, 'pi_wiloke_panel'));
        add_shortcode('pi_wiloke_divider', array($this, 'pi_wiloke_divider'));
        add_shortcode('pi_wiloke_customcontent', array($this, 'pi_wiloke_customcontent'));
        add_shortcode('pi_wiloke_col', array($this, 'pi_wiloke_col'));
        add_shortcode('pi_wiloke_row', array($this, 'pi_wiloke_row'));
    }    

    public function pi_enqueue_scripts()
    {
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-ui-accordion');

        wp_register_style('pi-shortcode-style', plugin_dir_url(__FILE__) . 'fe-assets/css/shortcode.css');
        wp_enqueue_style('pi-shortcode-style');
    }

    public function pi_wiloke_row($atts, $content=null)
    {
        $output = "";
        include ( 'pi_wiloke_row.php' );
        return $output;
    }

    public function pi_wiloke_col($atts, $content=null)
    {
        $output = "";
        include ( 'pi_wiloke_col.php' );
        return $output;
    }

    public function pi_wiloke_divider($atts)
    {
        $output = "";
        include (  'pi_wiloke_divider.php' );
        return $output;
    }


    public function pi_wiloke_customcontent($atts)
    {
        $output = "";
        include (  'pi_wiloke_customcontent.php' );
        return $output;
    }

    public function pi_wiloke_panel($atts)
    {
        $output = "";
        include (  'pi_wiloke_panel.php' );
        return $output;
    }

    public function pi_wiloke_quote($atts)
    {
        $output = "";
        include (  'pi_wiloke_quote.php' );
        return $output;
    }


    public function pi_wiloke_button($atts)
    {
        $output = "";
        include (  'pi_wiloke_button.php' );
        return $output;
    }

    public function pi_wiloke_contact($atts)
    {
        $output = "";
        include (  'pi_wiloke_contact.php' );
        return $output;
    }

    public function pi_item($atts)
    {
        $output = "";
        include (  'pi_item.php' );
        return $output;
    }

    public function pi_wiloke_progress($atts)
    {
        $output = "";
        include (  'pi_wiloke_progress.php' );
        return $output;
    }

    public function pi_wiloke_alert($atts)
    {
        $output = "";
        include (  'pi_wiloke_alert.php' );
        return $output;
    }

    public function pi_wiloke_accordion($atts, $content="")
    {
        $output = "";
        $output .= '<div class="pi-accordion">';
        $output .= do_shortcode($content);
        $output .= '</div>';
        return $output;
    }

    public function pi_tab($atts)
    {
        $output = "";
        include ( 'pi_wiloke_tab.php' );
        return $output;
    }

    public function pi_wiloke_tabs($atts, $content="")
    {
        $output = "";
        $output .= '<div class="pi-tabs">';
        $output .= '<ul class="pi-tabs-title">';
        $output .= do_shortcode($content);
        $output .= '</ul>';
        $output .= '</div>';
        return $output;
    }


    /*
     * Register Button
     */
    public function pi_wiloke_add_mce_button() 
    {
        // check if WYSIWYG is enabled
        if ( 'true' == get_user_option( 'rich_editing' ) ) 
        {
            add_filter( 'mce_external_plugins', array($this, 'pi_wiloke_add_tinymce_plugin' ), 10);
            add_filter( 'mce_buttons', array($this, 'pi_wiloke_register_mce_button' ));
        } 
    }

    public function pi_shortcodes_in_customizer()
    {
        if ( 'true' == get_user_option( 'rich_editing' ) )
        {
            add_filter( 'mce_external_plugins', array($this, 'pi_wiloke_add_tinymce_plugin_in_customizer' ), 10);
            add_filter( 'mce_buttons', array($this, 'pi_wiloke_register_mce_button_in_customizer' ));
        } 
    }


    /*Admin scripts*/
    public function pi_wiloke_enqueue_scripts()
    {
        if ( 'true' == get_user_option( 'rich_editing' ) ) 
        {
            $url = plugin_dir_url(__FILE__) . 'assets/';

            wp_register_style('pi-thickbox-style', $url . 'css/pi.thickbox.css', array(), '1.0');
            wp_register_style('pi-bootstrap', $url . 'css/bootstrap.css', array(), '1.0');
            wp_enqueue_style('pi-bootstrap');
            wp_enqueue_style('thickbox');
            wp_enqueue_style('pi-thickbox-style');
            wp_enqueue_script('thickbox');
            wp_localize_script('jquery', 'ARVIOSASSETURL', admin_url('amdin-ajax.php'));
            wp_localize_script('jquery', 'PIIMGURL', plugin_dir_url(__FILE__) . 'assets/images/');
        }
    }
    

    // Declare script for new button
    public function pi_wiloke_add_tinymce_plugin( $plugin_array ) 
    {

        $url = plugin_dir_url(__FILE__) . 'assets/';
        // $min = SCRIP_DEBUG ? ".min." : ".";
        $min = ".";
        $plugin_array['pi_shortcodes'] = $url .'js/pi.shortcodes'.$min.'js';
        $plugin_array['pi_columns'] = $url .'js/pi.columns'.$min.'js';
        return $plugin_array;
    }

    // Register new button in the editor
    public function pi_wiloke_register_mce_button( $buttons ) 
    {
        $apiShortcodebuttons = array("pi_columns", "pi_shortcodes");
        $buttons = array_merge($buttons, $apiShortcodebuttons);
        return $buttons;     
    }

    /*Customizer*/
    // Declare script for new button
    public function pi_wiloke_add_tinymce_plugin_in_customizer( $plugin_array ) 
    {
        $url = plugin_dir_url(__FILE__) . 'assets/';
        // $min = SCRIP_DEBUG ? ".min." : ".";
        $min = ".";
        $plugin_array['pi_shortcodes_in_customizer'] = $url .'js/pi.shortcodes-customizer'.$min.'js';
        return $plugin_array; 
    }

    // Register new button in the editor
    public function pi_wiloke_register_mce_button_in_customizer( $buttons ) 
    {
        $buttons = array_merge($buttons, $this->aButtons);
        return $buttons;
    }

    public function pi_shortcode_settings()
    {
        if ( !has_action('customize control_init') )
        {
            include ("shortcodes/tpl.shortcodes.php");
        }
    }

}