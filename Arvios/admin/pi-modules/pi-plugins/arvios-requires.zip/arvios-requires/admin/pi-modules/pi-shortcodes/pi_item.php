<?php
$atts = shortcode_atts(
	array(
		'title'		=> 'Tab Title',
		'content'	=> 'Tab Content'
	),
	$atts
);


$output .= '<h3 class="pi-accordion-title">' . wp_unslash($atts['title']) . '</h3>';
$output .=  '<div>';
	$output .= '<p>' . wp_unslash($atts['content']) . '</p>';
$output .= '</div>';

return $output;