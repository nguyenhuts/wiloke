;(function($, window, document, undefined)
{ 
	"use strict";


	tinymce.PluginManager.add('pi_columns', function( editor, url ) 
	{
		editor.addButton( 'pi_columns', {
			text: 'Arvios Columns',
			icon: ARVIOSASSETURL + 'images/shorcodes.png',
			type: 'menubutton',
			menu: 
			[
				{
					text: 'Full Width',
					onclick: function()
					{
						piInsertIntoWpEditor('fullwidth');
					}
				},
				{	
					text: 'Two Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('twocolumns');
					},
				},
				
				{	
					text: 'Three Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('threecolumns');
					},
				},
				{	
					text: 'Four Columns',
					onclick: function()
					{ 
						piInsertIntoWpEditor('fourcolumns');
					},
				}
			]
		});
	});

	function piInsertIntoWpEditor(column)
	{
		var shortCodeVisual = "";
		switch ( column )
		{
			case 'fullwidth':
				shortCodeVisual = "[pi_wiloke_row]<br />[pi_wiloke_col width='1/1'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]<br />[/pi_wiloke_row]";
				break;

			case 'twocolumns':
				shortCodeVisual = "[pi_wiloke_row]<br />[pi_wiloke_col type='1/2'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/2'] <br> &nbsp;&nbsp;&nbsp;&nbsp; .... <br> [/pi_wiloke_col]<br />[/pi_wiloke_row]";
				break;

			case 'threecolumns':
				shortCodeVisual = "[pi_wiloke_row]<br />[pi_wiloke_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/3'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]<br />[/pi_wiloke_row]";
				break;

			case 'fourcolumns':
				shortCodeVisual = "[pi_wiloke_row]<br />[pi_wiloke_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col][pi_wiloke_col type='1/4'] <br> &nbsp;&nbsp;&nbsp;&nbsp; ....  <br> [/pi_wiloke_col]<br />[/pi_wiloke_row]";
				break;
		}

		/* get the TinyMCE version to account for API diffs */
		var tmce_ver = window.tinyMCE.majorVersion;

		if (tmce_ver >= 4) {
		 window.tinyMCE.execCommand('mceInsertContent', false, shortCodeVisual);
		} else {
		 window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, shortCodeVisual);
		}

		// $('.wp-editor-area#content').insertAtCaret(shortCodeText, '');
	}




})(jQuery, window, document)